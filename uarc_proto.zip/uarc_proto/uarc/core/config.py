"""
UARC Unified Configuration
===========================
Single config object controlling all 7 modules.
Supports loading from TOML / env vars / kwargs.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional
from uarc.core.types import Precision, DeviceType


@dataclass
class TDEConfig:
    """Token Difficulty Estimator settings."""
    context_dim:    int   = 128
    hidden_dim:     int   = 256
    n_hidden:       int   = 3
    tau_easy:       float = 2.5    # PPL threshold: easy → draft
    tau_hard:       float = 8.0    # PPL threshold: hard → full
    ema_alpha:      float = 0.95   # Threshold calibration smoothing
    calibration_window: int = 500  # Tokens between calibration runs
    lr:             float = 1e-3


@dataclass
class AIVMConfig:
    """AI Virtual Memory Manager settings."""
    vram_mb:  float = 8192.0    # 8 GB GPU VRAM
    ram_mb:   float = 32768.0   # 32 GB System RAM
    nvme_mb:  float = 524288.0  # 512 GB NVMe
    page_size_mb: float = 2.0   # 2 MB per page
    evict_threshold: float = 0.5
    pressure_hi:     float = 0.85
    min_free_pct:    float = 0.10
    decay_tau:       float = 30.0  # Recency decay constant (seconds)


@dataclass
class DPEConfig:
    """Dynamic Precision Engine settings."""
    default_budget_gb: float = 8.0
    min_precision:  Precision = Precision.INT4
    max_ppl_delta:  float = 0.5    # Maximum acceptable PPL degradation
    cache_plans:    bool  = True   # Cache precision plans by budget


@dataclass
class PLLConfig:
    """Predictive Layer Loader settings."""
    lookahead_k: int   = 4       # Layers to look ahead
    slack_ms:    float = 20.0    # Minimum lead time before prefetch
    ema_alpha:   float = 0.9     # EMA for timing estimates


@dataclass
class ACSConfig:
    """Adaptive Compute Scheduler settings."""
    max_batch_size:     int   = 32
    scheduling_interval_ms: float = 5.0
    gpu_saturation_threshold: float = 0.90
    intensity_break_even: float = 4.0   # FLOP/byte for GPU vs CPU


@dataclass
class NSCConfig:
    """Neural Semantic Cache settings."""
    embedding_dim:  int   = 256
    similarity_threshold: float = 0.92
    max_entries:    int   = 10_000
    ttl_seconds:    float = 3600.0
    hnsw_m:         int   = 16
    hnsw_ef:        int   = 50


@dataclass
class ServerConfig:
    """FastAPI server settings."""
    host:    str = "0.0.0.0"
    port:    int = 8000
    workers: int = 1
    log_level: str = "info"
    cors_origins: list[str] = field(default_factory=lambda: ["*"])


@dataclass
class ModelConfig:
    """Simulated model settings (replace with real model in production)."""
    name:        str = "uarc-sim-7b"
    n_layers:    int = 32
    n_params:    int = 7_000_000_000
    vocab_size:  int = 32_000
    hidden_dim:  int = 4_096
    simulate:    bool = True   # Use simulated model (no real weights needed)
    model_path:  Optional[str] = None


@dataclass
class UARCConfig:
    """
    Master configuration for the UARC runtime.
    All sub-configs have sensible defaults for a portable 8GB machine.
    """
    device:  DeviceType  = DeviceType.AUTO
    model:   ModelConfig = field(default_factory=ModelConfig)
    tde:     TDEConfig   = field(default_factory=TDEConfig)
    aivm:    AIVMConfig  = field(default_factory=AIVMConfig)
    dpe:     DPEConfig   = field(default_factory=DPEConfig)
    pll:     PLLConfig   = field(default_factory=PLLConfig)
    acs:     ACSConfig   = field(default_factory=ACSConfig)
    nsc:     NSCConfig   = field(default_factory=NSCConfig)
    server:  ServerConfig = field(default_factory=ServerConfig)

    # Feature flags
    enable_tde:  bool = True
    enable_nsc:  bool = True
    enable_dpe:  bool = True
    enable_pll:  bool = True
    enable_acs:  bool = True

    @classmethod
    def for_edge(cls) -> "UARCConfig":
        """Preset for edge/constrained hardware (4GB RAM, no GPU)."""
        cfg = cls()
        cfg.device = DeviceType.CPU
        cfg.aivm.vram_mb  = 0.0
        cfg.aivm.ram_mb   = 4096.0
        cfg.aivm.nvme_mb  = 65536.0
        cfg.dpe.default_budget_gb = 4.0
        cfg.acs.max_batch_size = 4
        cfg.model.n_layers = 32
        return cfg

    @classmethod
    def for_gpu(cls, vram_gb: float = 24.0) -> "UARCConfig":
        """Preset for GPU server."""
        cfg = cls()
        cfg.device = DeviceType.GPU
        cfg.aivm.vram_mb = vram_gb * 1024
        cfg.aivm.ram_mb  = 65536.0
        cfg.dpe.default_budget_gb = vram_gb * 0.8
        cfg.acs.max_batch_size = 64
        return cfg

    @classmethod
    def from_env(cls) -> "UARCConfig":
        """Load overrides from environment variables."""
        cfg = cls()
        if v := os.getenv("UARC_VRAM_GB"):
            cfg.aivm.vram_mb = float(v) * 1024
        if v := os.getenv("UARC_RAM_GB"):
            cfg.aivm.ram_mb = float(v) * 1024
        if v := os.getenv("UARC_MAX_BATCH"):
            cfg.acs.max_batch_size = int(v)
        if v := os.getenv("UARC_PORT"):
            cfg.server.port = int(v)
        if v := os.getenv("UARC_NSC_THRESHOLD"):
            cfg.nsc.similarity_threshold = float(v)
        if v := os.getenv("UARC_DEVICE"):
            cfg.device = DeviceType(v.lower())
        return cfg

    def to_dict(self) -> dict:
        return {
            "device":  self.device.value,
            "model":   self.model.__dict__,
            "memory": {
                "vram_gb": round(self.aivm.vram_mb / 1024, 1),
                "ram_gb":  round(self.aivm.ram_mb  / 1024, 1),
                "nvme_gb": round(self.aivm.nvme_mb / 1024, 1),
            },
            "features": {
                "tde": self.enable_tde,
                "nsc": self.enable_nsc,
                "dpe": self.enable_dpe,
                "pll": self.enable_pll,
                "acs": self.enable_acs,
            },
            "thresholds": {
                "tau_easy": self.tde.tau_easy,
                "tau_hard": self.tde.tau_hard,
                "nsc_threshold": self.nsc.similarity_threshold,
            },
        }
