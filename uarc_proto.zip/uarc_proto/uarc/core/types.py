"""
UARC Core Types
===============
All shared dataclasses, enums, and type aliases used across modules.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import IntEnum, Enum
from typing import Optional, Any


# ── Enumerations ──────────────────────────────────────────────────────────────

class MemoryTier(IntEnum):
    VRAM = 0   # GPU HBM — fastest
    RAM  = 1   # System DRAM
    NVME = 2   # NVMe SSD — slowest

    @property
    def label(self) -> str:
        return {0: "VRAM", 1: "RAM", 2: "NVMe"}[self.value]

    @property
    def bandwidth_gbs(self) -> float:
        """Typical sequential bandwidth GB/s."""
        return {0: 900.0, 1: 80.0, 2: 7.0}[self.value]


class Precision(Enum):
    INT4  = 4
    INT8  = 8
    FP16  = 16
    BF16  = 16   # same bits as FP16, different format
    FP32  = 32

    @property
    def bytes_per_param(self) -> float:
        return self.value / 8

    def __lt__(self, other: "Precision") -> bool:
        return self.value < other.value


class RouteTarget(Enum):
    DRAFT   = "draft"    # Small draft model or n-gram cache
    PARTIAL = "partial"  # Full model, skip top 30% layers
    FULL    = "full"     # Full model, all layers


class RequestPriority(IntEnum):
    REALTIME = 0
    STANDARD = 1
    BATCH    = 2


class DeviceType(Enum):
    CPU  = "cpu"
    GPU  = "gpu"
    AUTO = "auto"


# ── Core Request / Response ───────────────────────────────────────────────────

@dataclass
class InferenceRequest:
    request_id: str
    prompt: str
    token_ids: list[int] = field(default_factory=list)
    max_new_tokens: int = 256
    temperature: float = 1.0
    priority: RequestPriority = RequestPriority.STANDARD
    deadline_ts: float = field(default_factory=lambda: time.time() + 30.0)
    stream: bool = False
    # Filled by runtime
    submitted_ts: float = field(default_factory=time.time)
    estimated_tokens: int = 128
    difficulty_score: float = 5.0
    prefix_hash: str = ""

    def sla_remaining_ms(self) -> float:
        return max(0.0, (self.deadline_ts - time.time()) * 1000)


@dataclass
class InferenceResponse:
    request_id: str
    text: str
    token_ids: list[int]
    # Performance metadata
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: float = 0.0
    tokens_per_second: float = 0.0
    # Routing metadata
    route_taken: str = "full"
    cache_hit: bool = False
    precision_plan_summary: dict = field(default_factory=dict)
    compute_saved_pct: float = 0.0


@dataclass
class RoutingDecision:
    route: RouteTarget
    estimated_ppl: float
    confidence: float
    latency_ms: float
    compute_saved_pct: float

    @property
    def label(self) -> str:
        return self.route.value


@dataclass
class PrecisionPlan:
    assignment: list[Precision]   # Per layer
    total_bytes: int
    estimated_ppl_delta: float
    memory_budget_bytes: int
    created_ts: float = field(default_factory=time.time)

    @property
    def avg_bits(self) -> float:
        if not self.assignment:
            return 0.0
        return sum(p.value for p in self.assignment) / len(self.assignment)

    def summary(self) -> dict:
        from collections import Counter
        counts = Counter(p.name for p in self.assignment)
        return {
            "avg_bits": round(self.avg_bits, 2),
            "total_mb": round(self.total_bytes / 1e6, 1),
            "ppl_delta": round(self.estimated_ppl_delta, 4),
            "precision_counts": dict(counts),
        }


# ── Memory Types ──────────────────────────────────────────────────────────────

@dataclass
class AIPage:
    page_id: str
    size_mb: float
    tier: MemoryTier
    data_type: str           # "weight" | "kv_cache" | "activation"
    layer_id: Optional[int] = None
    seq_id:   Optional[str] = None
    pinned:   bool = False
    dirty:    bool = False
    referenced: bool = False
    transfer_in_progress: bool = False
    access_count: int = 0
    created_ts: float = field(default_factory=time.time)
    last_access_ts: float = field(default_factory=time.time)

    def touch(self) -> None:
        self.access_count += 1
        self.last_access_ts = time.time()
        self.referenced = True

    def age_seconds(self) -> float:
        return time.time() - self.last_access_ts

    def score(self, alpha: float = 4.0, beta: float = 2.0,
              gamma: float = 1.0, tau: float = 30.0) -> float:
        import math
        freq     = alpha * math.log(1 + self.access_count)
        recency  = beta  * math.exp(-self.age_seconds() / tau)
        penalty  = gamma * float(self.tier)
        return freq + recency - penalty

    def transfer_time_ms(self, dst_tier: MemoryTier) -> float:
        if self.tier == dst_tier:
            return 0.0
        # Bottleneck bandwidth is the slower of src and dst
        bw = min(self.tier.bandwidth_gbs, dst_tier.bandwidth_gbs)
        return (self.size_mb / 1024.0) / bw * 1000.0


@dataclass
class KVBlock:
    block_id: int
    seq_id: str
    logical_idx: int
    page_id: str
    n_tokens: int = 16
    ref_count: int = 1

    @property
    def is_shared(self) -> bool:
        return self.ref_count > 1


# ── Scheduling Types ──────────────────────────────────────────────────────────

@dataclass
class Batch:
    batch_id: str
    requests: list[InferenceRequest]
    formed_ts: float = field(default_factory=time.time)
    device: DeviceType = DeviceType.AUTO

    @property
    def size(self) -> int:
        return len(self.requests)

    @property
    def total_tokens(self) -> int:
        return sum(r.estimated_tokens for r in self.requests)

    @property
    def avg_difficulty(self) -> float:
        if not self.requests:
            return 0.0
        return sum(r.difficulty_score for r in self.requests) / len(self.requests)


@dataclass
class LayerProfile:
    layer_id: int
    n_params: int
    sensitivity: dict[Precision, float]   # ppl delta vs FP16 baseline


@dataclass
class PrefetchOrder:
    layer_id: int
    target_tier: MemoryTier
    urgency_ms: float
    estimated_load_ms: float


# ── System Stats ──────────────────────────────────────────────────────────────

@dataclass
class UARCStats:
    # Routing
    total_requests: int = 0
    cache_hits: int = 0
    draft_routes: int = 0
    partial_routes: int = 0
    full_routes: int = 0
    # Memory
    tier0_hits: int = 0
    tier1_hits: int = 0
    tier2_hits: int = 0
    evictions: int = 0
    # Performance
    total_tokens_generated: int = 0
    total_latency_ms: float = 0.0

    @property
    def cache_hit_rate(self) -> float:
        return self.cache_hits / max(self.total_requests, 1)

    @property
    def avg_latency_ms(self) -> float:
        return self.total_latency_ms / max(self.total_requests, 1)

    @property
    def compute_saved_pct(self) -> float:
        n = max(self.total_requests - self.cache_hits, 1)
        saved = 0.85 * self.draft_routes + 0.35 * self.partial_routes
        return 100.0 * saved / n

    def to_dict(self) -> dict:
        return {
            "total_requests":        self.total_requests,
            "cache_hit_rate":        f"{self.cache_hit_rate:.1%}",
            "route_distribution": {
                "cache":   self.cache_hits,
                "draft":   self.draft_routes,
                "partial": self.partial_routes,
                "full":    self.full_routes,
            },
            "memory_tier_hits": {
                "tier0_vram": self.tier0_hits,
                "tier1_ram":  self.tier1_hits,
                "tier2_nvme": self.tier2_hits,
            },
            "evictions":             self.evictions,
            "total_tokens":          self.total_tokens_generated,
            "avg_latency_ms":        round(self.avg_latency_ms, 2),
            "compute_saved_pct":     round(self.compute_saved_pct, 1),
        }
