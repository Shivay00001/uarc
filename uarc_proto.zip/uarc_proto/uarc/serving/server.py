"""
UARC FastAPI Server — OpenAI-Compatible REST API
=================================================
Endpoints:
  POST /v1/chat/completions     (OpenAI chat format)
  POST /v1/completions          (OpenAI completion format)
  GET  /v1/models               (model list)
  GET  /health                  (health check)
  GET  /status                  (full runtime status)
  GET  /metrics                 (Prometheus-style text metrics)
  POST /admin/cache/clear       (flush NSC)
  POST /admin/evict             (trigger memory eviction)
"""
from __future__ import annotations

import time
import uuid
import asyncio
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, PlainTextResponse
from pydantic import BaseModel, Field

from uarc.core.config import UARCConfig
from uarc.core.runtime import UARCRuntime
from uarc.core.types import InferenceRequest, RequestPriority


# ── Global runtime (initialised in lifespan) ─────────────────────────────────
_runtime: Optional[UARCRuntime] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _runtime
    cfg = UARCConfig.from_env()
    _runtime = UARCRuntime(cfg)
    _runtime.start()
    yield
    _runtime.stop()


app = FastAPI(
    title="UARC Inference Server",
    description="Unified Adaptive Runtime Core — OpenAI-compatible LLM inference",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Pydantic Models ───────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str
    content: str


class ChatCompletionRequest(BaseModel):
    model: str = "uarc-sim-7b"
    messages: list[ChatMessage]
    max_tokens: int = Field(default=256, ge=1, le=4096)
    temperature: float = Field(default=1.0, ge=0.0, le=2.0)
    stream: bool = False
    priority: str = "standard"


class CompletionRequest(BaseModel):
    model: str = "uarc-sim-7b"
    prompt: str
    max_tokens: int = Field(default=256, ge=1, le=4096)
    temperature: float = Field(default=1.0, ge=0.0, le=2.0)
    stream: bool = False
    priority: str = "standard"


def _priority(s: str) -> RequestPriority:
    return {
        "realtime": RequestPriority.REALTIME,
        "standard": RequestPriority.STANDARD,
        "batch":    RequestPriority.BATCH,
    }.get(s.lower(), RequestPriority.STANDARD)


def _make_request(prompt: str, max_tokens: int,
                  temperature: float, priority: str,
                  stream: bool) -> InferenceRequest:
    return InferenceRequest(
        request_id=str(uuid.uuid4()),
        prompt=prompt,
        max_new_tokens=max_tokens,
        temperature=temperature,
        priority=_priority(priority),
        stream=stream,
    )


# ── OpenAI Endpoints ──────────────────────────────────────────────────────────

@app.post("/v1/chat/completions")
async def chat_completions(req: ChatCompletionRequest):
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")

    # Flatten messages to prompt
    prompt = "\n".join(
        f"{m.role.upper()}: {m.content}" for m in req.messages
    )
    ir = _make_request(prompt, req.max_tokens,
                       req.temperature, req.priority, req.stream)

    if req.stream:
        async def _stream():
            yield 'data: {"object":"chat.completion.chunk","choices":[{"delta":{"role":"assistant"}}]}\n\n'
            loop = asyncio.get_event_loop()
            gen  = await loop.run_in_executor(None, _runtime.infer_stream, ir)
            for chunk in gen:
                safe = chunk.replace('"', '\\"')
                yield f'data: {{"object":"chat.completion.chunk","choices":[{{"delta":{{"content":"{safe}"}}}}]}}\n\n'
            yield "data: [DONE]\n\n"
        return StreamingResponse(_stream(), media_type="text/event-stream")

    loop = asyncio.get_event_loop()
    resp = await loop.run_in_executor(None, _runtime.infer, ir)
    t    = int(time.time())

    return {
        "id":      f"chatcmpl-{resp.request_id[:8]}",
        "object":  "chat.completion",
        "created": t,
        "model":   req.model,
        "choices": [{
            "index":         0,
            "message":       {"role": "assistant", "content": resp.text},
            "finish_reason": "stop",
        }],
        "usage": {
            "prompt_tokens":     resp.prompt_tokens,
            "completion_tokens": resp.completion_tokens,
            "total_tokens":      resp.prompt_tokens + resp.completion_tokens,
        },
        "_uarc": {
            "route":           resp.route_taken,
            "cache_hit":       resp.cache_hit,
            "latency_ms":      resp.latency_ms,
            "tokens_per_sec":  resp.tokens_per_second,
            "compute_saved":   f"{resp.compute_saved_pct:.1f}%",
            "precision":       resp.precision_plan_summary,
        },
    }


@app.post("/v1/completions")
async def completions(req: CompletionRequest):
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")

    ir = _make_request(req.prompt, req.max_tokens,
                       req.temperature, req.priority, req.stream)

    if req.stream:
        async def _stream():
            loop = asyncio.get_event_loop()
            gen  = await loop.run_in_executor(None, _runtime.infer_stream, ir)
            for chunk in gen:
                safe = chunk.replace('"', '\\"')
                yield f'data: {{"object":"text_completion","choices":[{{"text":"{safe}"}}]}}\n\n'
            yield "data: [DONE]\n\n"
        return StreamingResponse(_stream(), media_type="text/event-stream")

    loop = asyncio.get_event_loop()
    resp = await loop.run_in_executor(None, _runtime.infer, ir)

    return {
        "id":      f"cmpl-{resp.request_id[:8]}",
        "object":  "text_completion",
        "created": int(time.time()),
        "model":   req.model,
        "choices": [{"text": resp.text, "index": 0, "finish_reason": "stop"}],
        "usage": {
            "prompt_tokens":     resp.prompt_tokens,
            "completion_tokens": resp.completion_tokens,
            "total_tokens":      resp.prompt_tokens + resp.completion_tokens,
        },
        "_uarc": {
            "route":     resp.route_taken,
            "cache_hit": resp.cache_hit,
            "latency_ms": resp.latency_ms,
        },
    }


@app.get("/v1/models")
async def list_models():
    return {
        "object": "list",
        "data": [{
            "id":       "uarc-sim-7b",
            "object":   "model",
            "created":  1700000000,
            "owned_by": "uarc",
            "permission": [],
        }],
    }


# ── Health & Status ───────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")
    return {"status": "ok", "version": "0.1.0"}


@app.get("/status")
async def status():
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")
    return _runtime.status()


@app.get("/metrics", response_class=PlainTextResponse)
async def metrics():
    """Prometheus-compatible text format."""
    if _runtime is None:
        return "# runtime not ready\n"
    s = _runtime._stats
    lines = [
        "# HELP uarc_requests_total Total inference requests",
        "# TYPE uarc_requests_total counter",
        f"uarc_requests_total {s.total_requests}",
        "# HELP uarc_cache_hits_total Cache hit count",
        f"uarc_cache_hits_total {s.cache_hits}",
        "# HELP uarc_tokens_generated_total Tokens generated",
        f"uarc_tokens_generated_total {s.total_tokens_generated}",
        "# HELP uarc_avg_latency_ms Average latency milliseconds",
        f"uarc_avg_latency_ms {s.avg_latency_ms:.2f}",
    ]
    return "\n".join(lines) + "\n"


# ── Admin Endpoints ───────────────────────────────────────────────────────────

@app.post("/admin/cache/clear")
async def clear_cache():
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")
    _runtime.nsc._store.clear()
    return {"cleared": True}


@app.post("/admin/evict")
async def force_evict():
    if _runtime is None:
        raise HTTPException(503, "Runtime not ready")
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, _runtime.aivm.run_eviction_cycle)
    return {"eviction": "complete", "memory": _runtime.aivm.status()}


# ── Entry point ───────────────────────────────────────────────────────────────

def main():
    import uvicorn
    from uarc.core.config import UARCConfig
    cfg = UARCConfig.from_env()
    uvicorn.run(
        "uarc.serving.server:app",
        host=cfg.server.host,
        port=cfg.server.port,
        log_level=cfg.server.log_level,
        reload=False,
    )


if __name__ == "__main__":
    main()
