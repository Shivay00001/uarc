"""
UARC CLI
=========
Commands:
  uarc run       "prompt"          — single inference
  uarc serve                       — start FastAPI server
  uarc bench     [--requests N]    — run benchmark
  uarc status                      — show runtime status
  uarc train-tde                   — train TDE on synthetic data
"""
from __future__ import annotations

import time
import uuid
import json
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.syntax import Syntax
from rich.live import Live
from rich import box

from uarc.core.config import UARCConfig
from uarc.core.runtime import UARCRuntime
from uarc.core.types import InferenceRequest, RequestPriority

app     = typer.Typer(name="uarc", help="Unified Adaptive Runtime Core — AI inference engine", add_completion=False)
console = Console()

# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_runtime(cfg: UARCConfig) -> UARCRuntime:
    rt = UARCRuntime(cfg)
    rt.start()
    return rt

def _tier_bar(pressure: float, width: int = 24) -> str:
    fill = int(pressure * width)
    color = "green" if pressure < 0.6 else ("yellow" if pressure < 0.85 else "red")
    bar  = "█" * fill + "░" * (width - fill)
    pct  = f"{pressure*100:5.1f}%"
    return f"[{color}]{bar}[/{color}] {pct}"

def _route_color(route: str) -> str:
    return {"draft": "green", "partial": "yellow",
            "full": "blue", "cache": "magenta"}.get(route, "white")

# ── Commands ──────────────────────────────────────────────────────────────────

@app.command()
def run(
    prompt: str = typer.Argument(..., help="Prompt text to complete"),
    max_tokens: int = typer.Option(128, "--max-tokens", "-n", help="Max new tokens"),
    priority: str  = typer.Option("standard", "--priority", "-p",
                                   help="Priority: realtime | standard | batch"),
    stream: bool   = typer.Option(False, "--stream", "-s", help="Stream output tokens"),
    vram_gb: float = typer.Option(8.0,  "--vram",  help="VRAM available (GB)"),
    ram_gb:  float = typer.Option(32.0, "--ram",   help="RAM available (GB)"),
    json_out: bool = typer.Option(False, "--json",  help="Output raw JSON"),
):
    """Run a single inference request through the full UARC pipeline."""
    cfg = UARCConfig.from_env()
    cfg.aivm.vram_mb = vram_gb * 1024
    cfg.aivm.ram_mb  = ram_gb  * 1024

    with console.status("[bold cyan]Starting UARC runtime…", spinner="dots"):
        rt = _get_runtime(cfg)

    req = InferenceRequest(
        request_id=str(uuid.uuid4()),
        prompt=prompt,
        max_new_tokens=max_tokens,
        priority={"realtime": RequestPriority.REALTIME,
                  "standard": RequestPriority.STANDARD,
                  "batch":    RequestPriority.BATCH}.get(priority, RequestPriority.STANDARD),
    )

    if stream:
        console.print(f"\n[dim]Streaming… (route will appear after)[/dim]\n")
        console.print("[bold white]", end="")
        for chunk in rt.infer_stream(req):
            console.print(chunk, end="", highlight=False)
        console.print("[/bold white]\n")
        rt.stop()
        return

    with console.status("[bold cyan]Running inference…", spinner="arc"):
        resp = rt.infer(req)

    rt.stop()

    if json_out:
        console.print_json(json.dumps({
            "text": resp.text,
            "route": resp.route_taken,
            "latency_ms": resp.latency_ms,
            "tokens_per_second": resp.tokens_per_second,
            "cache_hit": resp.cache_hit,
            "compute_saved_pct": resp.compute_saved_pct,
        }))
        return

    # Rich display
    route_c = _route_color(resp.route_taken)
    console.print()
    console.print(Panel(
        f"[white]{resp.text}[/white]",
        title="[bold]Completion[/bold]",
        border_style="cyan",
        padding=(1, 2),
    ))

    table = Table(box=box.ROUNDED, show_header=False, border_style="dim")
    table.add_column("Key",   style="dim", width=22)
    table.add_column("Value", style="bold")
    table.add_row("Route",          f"[{route_c}]{resp.route_taken.upper()}[/{route_c}]")
    table.add_row("Cache hit",      "✓ YES" if resp.cache_hit else "✗ no")
    table.add_row("Latency",        f"{resp.latency_ms:.1f} ms")
    table.add_row("Tokens/sec",     f"{resp.tokens_per_second:.1f}")
    table.add_row("Tokens (p/c)",   f"{resp.prompt_tokens} / {resp.completion_tokens}")
    table.add_row("Compute saved",  f"{resp.compute_saved_pct:.0f}%")
    if resp.precision_plan_summary:
        ps = resp.precision_plan_summary
        table.add_row("Precision avg", f"{ps.get('avg_bits', '?')} bits/weight")
        table.add_row("Memory used",   f"{ps.get('total_mb', '?')} MB")
    console.print(table)
    console.print()


@app.command()
def serve(
    host: str  = typer.Option("0.0.0.0", help="Bind host"),
    port: int  = typer.Option(8000,      help="Port"),
    vram_gb: float = typer.Option(8.0,   help="VRAM (GB)"),
    ram_gb:  float = typer.Option(32.0,  help="RAM (GB)"),
    log_level: str = typer.Option("info", help="Log level"),
):
    """Start the OpenAI-compatible UARC inference server."""
    import os
    os.environ["UARC_VRAM_GB"] = str(vram_gb)
    os.environ["UARC_RAM_GB"]  = str(ram_gb)
    os.environ["UARC_PORT"]    = str(port)

    console.print(Panel(
        f"[bold cyan]UARC Server[/bold cyan]\n\n"
        f"  [dim]Host:[/dim]          {host}:{port}\n"
        f"  [dim]VRAM:[/dim]          {vram_gb} GB\n"
        f"  [dim]RAM:[/dim]           {ram_gb} GB\n\n"
        f"  [dim]Chat API:[/dim]      http://{host}:{port}/v1/chat/completions\n"
        f"  [dim]Completions:[/dim]   http://{host}:{port}/v1/completions\n"
        f"  [dim]Status:[/dim]        http://{host}:{port}/status\n"
        f"  [dim]Metrics:[/dim]       http://{host}:{port}/metrics",
        title="[bold]Starting UARC Server[/bold]",
        border_style="cyan",
    ))

    import uvicorn
    uvicorn.run(
        "uarc.serving.server:app",
        host=host, port=port, log_level=log_level,
    )


@app.command()
def bench(
    requests:  int   = typer.Option(50,   "--requests",  "-n", help="Number of requests"),
    concurrency: int = typer.Option(1,    "--concurrency","-c", help="Concurrent requests"),
    max_tokens: int  = typer.Option(64,   "--max-tokens",      help="Max new tokens"),
    vram_gb: float   = typer.Option(8.0,  "--vram",            help="VRAM (GB)"),
    ram_gb:  float   = typer.Option(32.0, "--ram",             help="RAM (GB)"),
    seed_cache: bool = typer.Option(True, "--seed-cache/--no-seed-cache",
                                    help="Pre-warm NSC with duplicate prompts"),
):
    """Run a throughput/latency benchmark across all UARC modules."""
    import random
    rng = random.Random(0)

    cfg = UARCConfig.from_env()
    cfg.aivm.vram_mb = vram_gb * 1024
    cfg.aivm.ram_mb  = ram_gb  * 1024

    PROMPTS = [
        "Explain quantum entanglement in simple terms",
        "Write a Python function to sort a list",
        "What is the capital of France?",
        "Summarise the French Revolution",
        "How does backpropagation work?",
        "What are the benefits of renewable energy?",
        "Write a haiku about mountains",
        "Explain the TCP/IP stack",
        "What is a transformer model?",
        "How do vaccines work?",
    ]

    with console.status("[bold cyan]Starting UARC runtime…", spinner="dots"):
        rt = _get_runtime(cfg)

    # Optionally seed cache
    if seed_cache:
        with console.status("[bold cyan]Seeding semantic cache…", spinner="dots"):
            for p in PROMPTS[:5]:
                req = InferenceRequest(request_id=str(uuid.uuid4()),
                                       prompt=p, max_new_tokens=max_tokens)
                rt.infer(req)

    console.print(f"\n[bold]Running {requests} requests…[/bold]\n")

    latencies  = []
    routes     = {"draft": 0, "partial": 0, "full": 0, "cache": 0}
    tps_vals   = []
    errors     = 0

    with Progress(
        SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
        BarColumn(), TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(), console=console,
    ) as progress:
        task = progress.add_task("Inference", total=requests)

        for i in range(requests):
            prompt = rng.choice(PROMPTS)
            # 30% chance of near-duplicate (tests NSC)
            if rng.random() < 0.30 and i > 5:
                prompt = rng.choice(PROMPTS[:5])

            req = InferenceRequest(
                request_id=str(uuid.uuid4()),
                prompt=prompt,
                max_new_tokens=max_tokens,
                priority=rng.choice(list(RequestPriority)),
            )
            try:
                resp = rt.infer(req)
                latencies.append(resp.latency_ms)
                routes[resp.route_taken] = routes.get(resp.route_taken, 0) + 1
                tps_vals.append(resp.tokens_per_second)
            except Exception as e:
                errors += 1
            progress.advance(task)

    rt.stop()

    # Results
    latencies.sort()
    n = max(len(latencies), 1)
    p50 = latencies[int(n * 0.50)]
    p95 = latencies[int(n * 0.95)]
    p99 = latencies[min(int(n * 0.99), n-1)]
    avg_lat = sum(latencies) / n
    avg_tps = sum(tps_vals) / max(len(tps_vals), 1)
    total_s = sum(latencies) / 1000
    rps     = n / max(total_s, 0.001)

    console.print()
    console.print(Panel("[bold cyan]Benchmark Results[/bold cyan]", border_style="cyan"))

    lat_table = Table(title="Latency", box=box.ROUNDED, border_style="dim")
    lat_table.add_column("Metric", style="dim")
    lat_table.add_column("Value",  style="bold green")
    lat_table.add_row("Avg",    f"{avg_lat:.1f} ms")
    lat_table.add_row("p50",    f"{p50:.1f} ms")
    lat_table.add_row("p95",    f"{p95:.1f} ms")
    lat_table.add_row("p99",    f"{p99:.1f} ms")
    lat_table.add_row("Avg tok/s", f"{avg_tps:.1f}")
    lat_table.add_row("Req/s (wall)", f"{rps:.2f}")

    rt_table = Table(title="Route Distribution", box=box.ROUNDED, border_style="dim")
    rt_table.add_column("Route",  style="dim")
    rt_table.add_column("Count",  style="bold")
    rt_table.add_column("Pct",    style="bold")
    rt_table.add_column("Compute Saved")
    savings = {"cache": 100, "draft": 85, "partial": 35, "full": 0}
    for route, count in sorted(routes.items(), key=lambda x: -x[1]):
        c = _route_color(route)
        pct = 100 * count / n
        saved = savings.get(route, 0)
        rt_table.add_row(
            f"[{c}]{route}[/{c}]",
            str(count),
            f"{pct:.1f}%",
            f"[green]{saved}%[/green]" if saved > 0 else "0%",
        )

    from rich.columns import Columns
    console.print(Columns([lat_table, rt_table]))

    weighted_saved = sum(savings.get(r, 0) * c for r, c in routes.items()) / n
    console.print(f"\n  [bold]Avg compute saved:[/bold] [green]{weighted_saved:.1f}%[/green]")
    console.print(f"  [bold]Errors:[/bold] {errors}")
    console.print()


@app.command()
def status(
    vram_gb: float = typer.Option(8.0, "--vram", help="VRAM (GB)"),
    ram_gb: float  = typer.Option(32.0,"--ram",  help="RAM (GB)"),
):
    """Show full UARC runtime status and memory state."""
    cfg = UARCConfig.from_env()
    cfg.aivm.vram_mb = vram_gb * 1024
    cfg.aivm.ram_mb  = ram_gb  * 1024

    with console.status("[bold cyan]Starting UARC…", spinner="dots"):
        rt = _get_runtime(cfg)
    s = rt.status()
    rt.stop()

    console.print()
    console.print(Panel("[bold cyan]UARC Runtime Status[/bold cyan]", border_style="cyan"))

    # Memory
    mem_table = Table(title="Memory Tiers", box=box.ROUNDED, border_style="dim")
    mem_table.add_column("Tier",     style="bold", width=8)
    mem_table.add_column("Usage",    width=36)
    mem_table.add_column("Used",     width=12)
    mem_table.add_column("Free",     width=12)
    mem_table.add_column("Cap",      width=12)
    for tier_name in ["VRAM", "RAM", "NVMe"]:
        t = s["memory"].get(tier_name, {})
        if t.get("capacity_mb", 0) == 0:
            continue
        mem_table.add_row(
            tier_name,
            _tier_bar(t["pressure"]),
            f"{t['used_mb']:.0f} MB",
            f"{t['free_mb']:.0f} MB",
            f"{t['capacity_mb']:.0f} MB",
        )
    console.print(mem_table)

    # Modules
    mod_table = Table(title="Module Status", box=box.ROUNDED, border_style="dim")
    mod_table.add_column("Module",  style="bold", width=10)
    mod_table.add_column("Key Metric")
    modules = s.get("modules", {})
    if "tde" in modules:
        t = modules["tde"]
        mod_table.add_row("TDE", f"τ_easy={t['tau_easy']}  τ_hard={t['tau_hard']}  routed={t['total_routed']}")
    if "nsc" in modules:
        t = modules["nsc"]
        mod_table.add_row("NSC", f"size={t['size']}  hit_rate={t['hit_rate']:.1%}  threshold={t['threshold']}")
    if "dpe" in modules:
        mod_table.add_row("DPE", f"cached_plans={modules['dpe']['cached_plans']}")
    if "pll" in modules:
        t = modules["pll"]
        mod_table.add_row("PLL", f"prefetches={t['prefetch_issued']}  exec_ema={t['avg_exec_ema_ms']}ms")
    if "acs" in modules:
        t = modules["acs"]
        mod_table.add_row("ACS", f"batches={t['batches_formed']}  avg_size={t['avg_batch_size']}  pending={t['pending']}")
    console.print(mod_table)

    perf = s.get("performance", {})
    console.print(f"\n  Requests: [bold]{perf.get('total_requests', 0)}[/bold]  "
                  f"Cache hit rate: [bold green]{perf.get('cache_hit_rate', '0%')}[/bold green]  "
                  f"Avg latency: [bold]{perf.get('avg_latency_ms', 0):.1f}ms[/bold]  "
                  f"Compute saved: [bold green]{perf.get('compute_saved_pct', 0):.1f}%[/bold green]\n")


@app.command("train-tde")
def train_tde(
    samples:  int   = typer.Option(500, "--samples",  help="Training samples"),
    epochs:   int   = typer.Option(5,   "--epochs",   help="Training epochs"),
    save:     Optional[str] = typer.Option(None, "--save", help="Save weights to path (future)"),
):
    """Train the Token Difficulty Estimator on synthetic perplexity data."""
    import random
    rng = random.Random(42)

    from uarc.core.config import TDEConfig
    from uarc.routing.tde import TokenDifficultyEstimator

    cfg = TDEConfig()
    tde = TokenDifficultyEstimator(cfg)

    console.print(f"\n[bold]Generating {samples} training samples…[/bold]")
    dataset = []
    for _ in range(samples):
        n = rng.randint(32, 128)
        toks = [rng.randint(0, 32000) for _ in range(n)]
        avg  = sum(toks) / n
        if avg < 10000:   ppl = rng.uniform(1.5, 4.0)
        elif avg < 22000: ppl = rng.uniform(4.0, 10.0)
        else:             ppl = rng.uniform(10.0, 25.0)
        dataset.append((toks, ppl))

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                  BarColumn(), TextColumn("loss={task.fields[loss]:.4f}"),
                  console=console) as progress:
        task = progress.add_task("Training", total=epochs, loss=0.0)
        losses = []
        for epoch in range(epochs):
            loss = tde.train(dataset[:10], epochs=1)[0]   # mini-step for demo
            losses.append(loss)
            progress.update(task, advance=1, loss=loss)

    console.print(f"\n  [bold green]✓ Training complete[/bold green]")
    console.print(f"  Final loss: [bold]{losses[-1]:.4f}[/bold]")
    s = tde.stats()
    console.print(f"  τ_easy={s['tau_easy']}  τ_hard={s['tau_hard']}\n")


if __name__ == "__main__":
    app()
