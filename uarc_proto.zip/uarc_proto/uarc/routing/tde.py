"""
M1: Token Difficulty Estimator (TDE)
=====================================
Predicts per-token perplexity → routes to draft / partial / full model.
Pure Python + NumPy. Drop-in replacement with torch in production.
"""
from __future__ import annotations

import math
import time
import random
from typing import Optional

import numpy as np

from uarc.core.config import TDEConfig
from uarc.core.types import RoutingDecision, RouteTarget


class ContextEncoder:
    """
    Encode last 128 tokens → context_dim embedding.
    Hash-based projection: O(1) wrt sequence length.
    Replace with MiniLM encoder in production.
    """
    def __init__(self, dim: int = 128, tau_pos: float = 32.0):
        self.dim = dim
        self.tau_pos = tau_pos
        # Precompute positional decay weights for window of 128
        self._pos_weights = np.array([
            math.exp(-i / tau_pos) for i in range(128)
        ], dtype=np.float32)

    def _hash_embed(self, token_id: int) -> np.ndarray:
        """Deterministic pseudo-embedding via seeded RNG."""
        rng = np.random.RandomState(token_id & 0x7FFFFFFF)
        return rng.randn(self.dim).astype(np.float32)

    def encode(self, token_ids: list[int]) -> np.ndarray:
        window = token_ids[-128:]
        n = len(window)
        if n == 0:
            return np.zeros(self.dim, dtype=np.float32)

        weights = self._pos_weights[-n:][::-1]   # recent = higher weight
        embeddings = np.stack([self._hash_embed(t) for t in window])
        weighted = (embeddings * weights[:, None]).sum(axis=0)
        total_w = weights.sum()
        result = weighted / max(total_w, 1e-9)
        # LayerNorm
        mu = result.mean()
        sigma = result.std() + 1e-6
        return ((result - mu) / sigma).astype(np.float32)


class MLP:
    """
    Regression MLP: context_dim → hidden_dim × n_hidden → 1 (log_ppl).
    NumPy forward pass + basic SGD. Production: replace with ONNX export.
    """
    def __init__(self, input_dim: int, hidden_dim: int,
                 n_hidden: int, lr: float = 1e-3):
        self.lr = lr
        dims = [input_dim] + [hidden_dim] * n_hidden + [1]
        # He initialisation for ReLU
        self.W: list[np.ndarray] = [
            np.random.randn(dims[i+1], dims[i]).astype(np.float32)
            * math.sqrt(2.0 / dims[i])
            for i in range(len(dims) - 1)
        ]
        self.b: list[np.ndarray] = [
            np.zeros(dims[i+1], dtype=np.float32)
            for i in range(len(dims) - 1)
        ]

    def forward(self, x: np.ndarray) -> tuple[float, list]:
        cache = [x]
        h = x.copy()
        for i in range(len(self.W) - 1):
            z = self.W[i] @ h + self.b[i]
            # LayerNorm
            z = (z - z.mean()) / (z.std() + 1e-6)
            h = np.maximum(0, z)   # ReLU
            cache.append(h)
        out = float((self.W[-1] @ h + self.b[-1])[0])
        cache.append(np.array([out]))
        return out, cache

    def backward_and_step(self, cache: list, target: float) -> float:
        """Simplified single-step SGD on output layer only."""
        pred = cache[-1][0]
        loss = (pred - target) ** 2
        grad = 2.0 * (pred - target)
        h_prev = cache[-2]
        self.W[-1] -= self.lr * grad * h_prev[None, :]
        self.b[-1] -= self.lr * grad * np.ones(1)
        return float(loss)

    def predict(self, x: np.ndarray) -> float:
        out, _ = self.forward(x)
        return math.exp(max(-10, min(10, out)))   # → perplexity


class TokenDifficultyEstimator:
    """
    Full TDE pipeline: token_ids → RoutingDecision.

    Usage:
        tde = TokenDifficultyEstimator(cfg)
        tde.train(dataset)   # offline
        decision = tde.estimate(token_ids)  # runtime
    """

    def __init__(self, cfg: TDEConfig):
        self.cfg = cfg
        self.encoder = ContextEncoder(dim=cfg.context_dim)
        self.mlp = MLP(cfg.context_dim, cfg.hidden_dim,
                       cfg.n_hidden, cfg.lr)
        # Adaptive thresholds
        self.tau_easy = cfg.tau_easy
        self.tau_hard = cfg.tau_hard
        # Calibration state
        self._calib_buf: list[tuple[float, float]] = []
        # Stats
        self.n_routed = 0
        self.route_counts = {r: 0 for r in RouteTarget}

    # ── Runtime API ───────────────────────────────────────────────────────────

    def estimate(self, token_ids: list[int]) -> RoutingDecision:
        t0 = time.perf_counter()
        emb = self.encoder.encode(token_ids)
        ppl = self.mlp.predict(emb)
        route, saved = self._route(ppl)
        conf = self._confidence(ppl)
        ms = (time.perf_counter() - t0) * 1000

        self.n_routed += 1
        self.route_counts[route] += 1

        return RoutingDecision(
            route=route,
            estimated_ppl=round(ppl, 3),
            confidence=round(conf, 3),
            latency_ms=round(ms, 3),
            compute_saved_pct=saved,
        )

    def _route(self, ppl: float) -> tuple[RouteTarget, float]:
        if ppl < self.tau_easy:
            return RouteTarget.DRAFT,   85.0
        elif ppl < self.tau_hard:
            return RouteTarget.PARTIAL, 35.0
        else:
            return RouteTarget.FULL,    0.0

    def _confidence(self, ppl: float) -> float:
        d = min(abs(ppl - self.tau_easy), abs(ppl - self.tau_hard))
        return 1.0 / (1.0 + math.exp(-(d - 1.0)))

    # ── Calibration ───────────────────────────────────────────────────────────

    def calibrate(self, est_ppl: float, actual_ppl: float) -> None:
        self._calib_buf.append((est_ppl, actual_ppl))
        if len(self._calib_buf) >= self.cfg.calibration_window:
            self._run_calibration()
            self._calib_buf.clear()

    def _run_calibration(self) -> None:
        errors = [a - e for e, a in self._calib_buf]
        bias = sum(errors) / len(errors)
        alpha = self.cfg.ema_alpha
        self.tau_easy = max(1.0, alpha * self.tau_easy + (1-alpha) * (self.tau_easy + bias))
        self.tau_hard = max(self.tau_easy + 1.0,
                            alpha * self.tau_hard + (1-alpha) * (self.tau_hard + bias))

    # ── Training ──────────────────────────────────────────────────────────────

    def train(self, dataset: list[tuple[list[int], float]],
              epochs: int = 3) -> list[float]:
        """Train on (token_ids, ppl) pairs. Returns per-epoch losses."""
        losses = []
        for epoch in range(epochs):
            total = 0.0
            random.shuffle(dataset)
            for token_ids, ppl in dataset:
                emb = self.encoder.encode(token_ids)
                target = math.log(max(ppl, 1e-6))
                _, cache = self.mlp.forward(emb)
                loss = self.mlp.backward_and_step(cache, target)
                total += loss
            avg = total / max(len(dataset), 1)
            losses.append(round(avg, 4))
        return losses

    # ── Stats ─────────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        n = max(self.n_routed, 1)
        return {
            "total_routed": self.n_routed,
            "route_pct": {
                r.value: round(100 * c / n, 1)
                for r, c in self.route_counts.items()
            },
            "tau_easy": round(self.tau_easy, 3),
            "tau_hard": round(self.tau_hard, 3),
            "estimated_compute_saved_pct": round(
                (85.0 * self.route_counts[RouteTarget.DRAFT] +
                 35.0 * self.route_counts[RouteTarget.PARTIAL]) / n, 1
            ),
        }
