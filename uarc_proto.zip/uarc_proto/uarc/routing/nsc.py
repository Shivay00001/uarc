"""
M6: Neural Semantic Cache (NSC)
================================
Embedding-based ANN cache. Returns completions for semantically
equivalent queries without running inference.
"""
from __future__ import annotations

import hashlib
import math
import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from uarc.core.config import NSCConfig


@dataclass
class CacheEntry:
    entry_id: str
    embedding: np.ndarray
    completion_tokens: list[int]
    completion_text: str
    prompt_hash: str
    created_ts: float = field(default_factory=time.time)
    last_access_ts: float = field(default_factory=time.time)
    access_count: int = 0

    def touch(self) -> None:
        self.last_access_ts = time.time()
        self.access_count += 1

    def age_seconds(self) -> float:
        return time.time() - self.last_access_ts


class BiEncoder:
    """
    Lightweight bi-encoder: token_ids → L2-normalised 256-dim vector.
    Deterministic hash projection (production: sentence-transformers).
    """
    def __init__(self, dim: int = 256):
        self.dim = dim

    def encode(self, token_ids: list[int]) -> np.ndarray:
        window = token_ids[-256:]
        result = np.zeros(self.dim, dtype=np.float64)
        for i, tok in enumerate(window):
            weight = math.exp(-i / 64.0)
            rng = np.random.RandomState(tok ^ 0xDEAD_BEEF)
            result += weight * rng.randn(self.dim)
        norm = np.linalg.norm(result)
        if norm > 1e-9:
            result /= norm
        return result.astype(np.float32)

    def encode_text(self, text: str) -> np.ndarray:
        """Encode raw text via character n-gram hashing."""
        tokens = [hash(text[i:i+3]) & 0xFFFFFF for i in range(len(text)-2)]
        if not tokens:
            tokens = [hash(text) & 0xFFFFFF]
        return self.encode(tokens)


class HNSWIndex:
    """
    Single-layer NSW index (approximates full HNSW).
    O(log N) search, O(N·M) space.
    Production: replace with faiss.IndexHNSWFlat.
    """
    def __init__(self, dim: int, M: int = 16, ef: int = 50):
        self.dim = dim
        self.M   = M
        self.ef  = ef
        self._vecs:  list[np.ndarray] = []
        self._ids:   list[str] = []
        self._graph: list[list[int]] = []

    def __len__(self) -> int:
        return len(self._vecs)

    def add(self, vec: np.ndarray, entry_id: str) -> int:
        idx = len(self._vecs)
        self._vecs.append(vec)
        self._ids.append(entry_id)
        self._graph.append([])
        if idx == 0:
            return idx
        # Connect to M nearest neighbours
        neighbours = self._greedy_search(vec, k=self.M, entry=0)
        self._graph[idx] = [n for n, _ in neighbours]
        for n, _ in neighbours:
            if len(self._graph[n]) < self.M * 2:
                self._graph[n].append(idx)
        return idx

    def search(self, query: np.ndarray, k: int = 1) -> list[tuple[str, float]]:
        if not self._vecs:
            return []
        results = self._greedy_search(query, k=k, entry=0)
        return [(self._ids[i], float(s)) for i, s in results[:k]]

    def _greedy_search(self, query: np.ndarray, k: int,
                       entry: int) -> list[tuple[int, float]]:
        import heapq
        visited = {entry}
        e_sim = float(query @ self._vecs[entry])
        heap   = [(-e_sim, entry)]          # min-heap on neg sim
        result = [(e_sim, entry)]

        while heap:
            neg_s, cur = heapq.heappop(heap)
            cur_s = -neg_s
            if result and cur_s < result[-1][0] and len(result) >= self.ef:
                break
            for nb in self._graph[cur]:
                if nb in visited:
                    continue
                visited.add(nb)
                nb_s = float(query @ self._vecs[nb])
                heapq.heappush(heap, (-nb_s, nb))
                result.append((nb_s, nb))
            if len(visited) > self.ef * 2:
                break

        result.sort(reverse=True)
        return [(i, s) for s, i in result[:k]]


class NeuralSemanticCache:
    """
    Full NSC: encode → ANN lookup → hit/miss → store.
    Thread-safe for single-writer / multi-reader workloads.
    """

    def __init__(self, cfg: NSCConfig):
        self.cfg = cfg
        self.encoder = BiEncoder(dim=cfg.embedding_dim)
        self.index   = HNSWIndex(cfg.embedding_dim, M=cfg.hnsw_m, ef=cfg.hnsw_ef)
        self._store: dict[str, CacheEntry] = {}
        self._counter = 0
        # Adaptive threshold
        self.threshold = cfg.similarity_threshold
        # Stats
        self.n_lookups = 0
        self.n_hits    = 0
        self.n_misses  = 0
        self.n_false_positives = 0
        self._total_lookup_ms = 0.0

    # ── Core API ──────────────────────────────────────────────────────────────

    def lookup(self, token_ids: list[int],
               prompt_text: str = "") -> Optional[tuple[list[int], str]]:
        """
        Returns (completion_tokens, completion_text) on hit, None on miss.
        Latency target: < 2ms.
        """
        t0 = time.perf_counter()
        self.n_lookups += 1

        emb = (self.encoder.encode_text(prompt_text)
               if prompt_text else self.encoder.encode(token_ids))

        results = self.index.search(emb, k=1)
        ms = (time.perf_counter() - t0) * 1000
        self._total_lookup_ms += ms

        if not results:
            self.n_misses += 1
            return None

        entry_id, sim = results[0]
        entry = self._store.get(entry_id)

        if entry is None or entry.age_seconds() > self.cfg.ttl_seconds:
            self.n_misses += 1
            if entry_id in self._store:
                del self._store[entry_id]
            return None

        if sim >= self.threshold:
            entry.touch()
            self.n_hits += 1
            return entry.completion_tokens, entry.completion_text

        self.n_misses += 1
        return None

    def store(self, token_ids: list[int], prompt_text: str,
              completion_tokens: list[int], completion_text: str) -> str:
        """Store a (prompt, completion) pair. Returns entry_id."""
        emb = (self.encoder.encode_text(prompt_text)
               if prompt_text else self.encoder.encode(token_ids))
        prompt_hash = hashlib.sha256(prompt_text.encode()).hexdigest()[:16]

        self._counter += 1
        entry_id = f"nsc_{self._counter:08d}"

        entry = CacheEntry(
            entry_id=entry_id,
            embedding=emb,
            completion_tokens=completion_tokens,
            completion_text=completion_text,
            prompt_hash=prompt_hash,
        )
        self.index.add(emb, entry_id)
        self._store[entry_id] = entry

        if len(self._store) > self.cfg.max_entries:
            self._evict_lru(batch=max(1, self.cfg.max_entries // 10))

        return entry_id

    def report_false_positive(self) -> None:
        """Signal bad hit → tighten threshold."""
        self.n_false_positives += 1
        fpr = self.n_false_positives / max(self.n_hits, 1)
        # Increase threshold if FPR too high
        if fpr > 0.02:
            self.threshold = min(0.99, self.threshold + 0.005)

    def _evict_lru(self, batch: int) -> None:
        sorted_entries = sorted(
            self._store.items(),
            key=lambda kv: kv[1].last_access_ts
        )
        for eid, _ in sorted_entries[:batch]:
            del self._store[eid]

    # ── Stats ─────────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        n = max(self.n_lookups, 1)
        return {
            "size":          len(self._store),
            "lookups":       self.n_lookups,
            "hits":          self.n_hits,
            "misses":        self.n_misses,
            "hit_rate":      round(self.n_hits / n, 3),
            "false_positives": self.n_false_positives,
            "threshold":     round(self.threshold, 4),
            "avg_lookup_ms": round(self._total_lookup_ms / n, 3),
        }
