"""
UARC — Unified Adaptive Runtime Core
=====================================
A portable, modular AI inference runtime combining:
  • Token Difficulty Estimation (TDE)
  • AI Virtual Memory Management (AI-VM)
  • Dynamic Precision Engine (DPE)
  • Predictive Layer Loading (PLL)
  • Adaptive Compute Scheduling (ACS)
  • Neural Semantic Caching (NSC)
  • Hybrid CPU/GPU Execution Router
"""

__version__ = "0.1.0"
__author__ = "UARC Project"

from uarc.core.config import UARCConfig
from uarc.core.runtime import UARCRuntime
from uarc.core.types import (
    InferenceRequest,
    InferenceResponse,
    RoutingDecision,
    PrecisionPlan,
)

__all__ = [
    "UARCConfig",
    "UARCRuntime",
    "InferenceRequest",
    "InferenceResponse",
    "RoutingDecision",
    "PrecisionPlan",
]
