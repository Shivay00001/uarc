"""
M3: Dynamic Precision Engine (DPE)
M5: Adaptive Compute Scheduler (ACS)
======================================
Greedy knapsack precision allocation + priority-weighted batch formation.
"""
from __future__ import annotations

import hashlib
import heapq
import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional

from uarc.core.config import DPEConfig, ACSConfig
from uarc.core.types import (
    Batch, InferenceRequest, LayerProfile,
    Precision, PrecisionPlan, RequestPriority, DeviceType,
)


# ══════════════════════════════════════════════════════════════════════════════
# Dynamic Precision Engine
# ══════════════════════════════════════════════════════════════════════════════

_PREC_ORDER = [Precision.INT4, Precision.INT8, Precision.FP16, Precision.FP32]


class DynamicPrecisionEngine:
    """
    M3: Runtime per-layer precision allocator.
    Greedy knapsack: O(L²) worst case, O(L log L) typical.
    Plans are cached per budget bucket to avoid recomputation.
    """

    def __init__(self, cfg: DPEConfig, profiles: list[LayerProfile]):
        self.cfg = cfg
        self.profiles = {p.layer_id: p for p in profiles}
        self.n_layers = len(profiles)
        self._cache: dict[int, PrecisionPlan] = {}

    # ── Core Allocation ───────────────────────────────────────────────────────

    def allocate(self, budget_bytes: Optional[int] = None) -> PrecisionPlan:
        if budget_bytes is None:
            budget_bytes = int(self.cfg.default_budget_gb * 1024**3)

        bucket = budget_bytes // (256 * 1024 * 1024)   # 256MB buckets
        if self.cfg.cache_plans and bucket in self._cache:
            return self._cache[bucket]

        assignment: dict[int, Precision] = {
            lid: Precision.INT4 for lid in self.profiles
        }

        def total_bytes(asgn: dict) -> int:
            return sum(
                int(self.profiles[lid].n_params * p.bytes_per_param)
                for lid, p in asgn.items()
            )

        def total_ppl_delta(asgn: dict) -> float:
            return sum(
                self.profiles[lid].sensitivity.get(p, 0.0)
                for lid, p in asgn.items()
            )

        current = total_bytes(assignment)

        # Greedy upgrade loop
        for _ in range(self.n_layers * len(_PREC_ORDER)):
            best_gpb   = -math.inf
            best_lid   = None
            best_prec  = None

            for lid, cur_p in assignment.items():
                idx = _PREC_ORDER.index(cur_p)
                if idx + 1 >= len(_PREC_ORDER):
                    continue
                nxt_p  = _PREC_ORDER[idx + 1]
                prof   = self.profiles[lid]
                Δbytes = int(prof.n_params * (nxt_p.bytes_per_param
                                              - cur_p.bytes_per_param))
                if current + Δbytes > budget_bytes:
                    continue
                gain = (prof.sensitivity.get(cur_p,  0.0) -
                        prof.sensitivity.get(nxt_p, 0.0))
                gpb  = gain / max(Δbytes, 1)
                if gpb > best_gpb:
                    best_gpb, best_lid, best_prec = gpb, lid, nxt_p

            if best_lid is None:
                break

            Δ = int(self.profiles[best_lid].n_params *
                    (best_prec.bytes_per_param -
                     assignment[best_lid].bytes_per_param))
            assignment[best_lid] = best_prec
            current += Δ

        plan = PrecisionPlan(
            assignment=[assignment[i] for i in sorted(assignment)],
            total_bytes=current,
            estimated_ppl_delta=round(total_ppl_delta(assignment), 4),
            memory_budget_bytes=budget_bytes,
        )
        if self.cfg.cache_plans:
            self._cache[bucket] = plan
        return plan

    def adapt_for_token(self, base: PrecisionPlan,
                        difficulty: float) -> PrecisionPlan:
        """Upgrade critical layers for hard tokens."""
        n = self.n_layers
        crit = list(range(n // 10)) + list(range(n * 9 // 10, n))
        asgn = list(base.assignment)

        if difficulty > 8.0:
            for lid in crit:
                if lid < len(asgn) and asgn[lid].value < 16:
                    asgn[lid] = Precision.FP16

        new_bytes = sum(
            int(self.profiles.get(i, LayerProfile(i, 1, {}))
                .n_params * asgn[i].bytes_per_param)
            for i in range(len(asgn))
        )
        return PrecisionPlan(
            assignment=asgn,
            total_bytes=new_bytes,
            estimated_ppl_delta=base.estimated_ppl_delta,
            memory_budget_bytes=base.memory_budget_bytes,
        )

    @staticmethod
    def build_profiles(n_layers: int,
                       params_per_layer: int = 100_000_000) -> list[LayerProfile]:
        """Generate realistic sensitivity profiles (U-shaped pattern)."""
        import random
        rng = random.Random(42)
        profiles = []
        for i in range(n_layers):
            edge = 1.0 - abs(i - n_layers/2) / (n_layers/2 + 1e-9)
            edge = 1.0 - edge   # high at edges, low in middle
            sens = {
                Precision.INT4:  round(edge * rng.uniform(0.3, 1.2) + 0.05, 4),
                Precision.INT8:  round(edge * rng.uniform(0.05, 0.3) + 0.01, 4),
                Precision.FP16:  0.0,
                Precision.FP32:  0.0,
            }
            profiles.append(LayerProfile(
                layer_id=i, n_params=params_per_layer, sensitivity=sens))
        return profiles

    def stats(self) -> dict:
        return {"cached_plans": len(self._cache)}


# ══════════════════════════════════════════════════════════════════════════════
# Adaptive Compute Scheduler
# ══════════════════════════════════════════════════════════════════════════════

class AdaptiveComputeScheduler:
    """
    M5: Priority-weighted, prefix-sharing-aware batch scheduler.
    Three priority heaps + prefix reordering for KV-cache efficiency.
    Thread-safe.
    """

    def __init__(self, cfg: ACSConfig):
        self.cfg = cfg
        self._queues: dict[RequestPriority, list] = {
            RequestPriority.REALTIME: [],
            RequestPriority.STANDARD: [],
            RequestPriority.BATCH:    [],
        }
        self._lock    = threading.Lock()
        self._seq     = 0          # tie-breaking counter
        self._batch_n = 0
        self.gpu_util = 0.0
        self.cpu_util = 0.0
        self.stats    = defaultdict(int)

    # ── Request Submission ────────────────────────────────────────────────────

    def submit(self, req: InferenceRequest) -> None:
        req.prefix_hash = self._hash_prefix(req.token_ids)
        score = self._score(req)
        with self._lock:
            self._seq += 1
            heapq.heappush(
                self._queues[req.priority],
                (-score, self._seq, req),
            )
        self.stats["submitted"] += 1

    def _score(self, req: InferenceRequest) -> float:
        remaining = max(req.sla_remaining_ms(), 1.0)
        return (3.0 / remaining +
                1.0 / max(req.estimated_tokens, 1) +
                float(req.priority == RequestPriority.REALTIME) * 1e6)

    def _hash_prefix(self, token_ids: list[int], n: int = 64) -> str:
        raw = str(token_ids[:n]).encode()
        return hashlib.md5(raw).hexdigest()[:8]

    # ── Batch Formation ───────────────────────────────────────────────────────

    def form_batch(self) -> Optional[Batch]:
        with self._lock:
            candidates: list[InferenceRequest] = []
            cap = self.cfg.max_batch_size

            for prio in RequestPriority:
                q = self._queues[prio]
                while q and len(candidates) < cap:
                    _, _, req = heapq.heappop(q)
                    candidates.append(req)

            if not candidates:
                return None

            ordered = self._reorder_by_prefix(candidates)
            self._batch_n += 1
            batch = Batch(
                batch_id=f"batch_{self._batch_n:06d}",
                requests=ordered,
            )
            self.stats["batches"] += 1
            self.stats["requests_batched"] += len(ordered)
            return batch

    def _reorder_by_prefix(self,
                            reqs: list[InferenceRequest]) -> list[InferenceRequest]:
        groups: dict[str, list[InferenceRequest]] = defaultdict(list)
        for r in reqs:
            groups[r.prefix_hash].append(r)
        shared = sum(len(g) - 1 for g in groups.values())
        self.stats["kv_sharing_pairs"] += shared
        # Largest groups first (maximum KV sharing)
        ordered: list[InferenceRequest] = []
        for g in sorted(groups.values(), key=len, reverse=True):
            ordered.extend(g)
        return ordered

    # ── Device Routing ────────────────────────────────────────────────────────

    def route(self, batch_size: int, n_params: int) -> DeviceType:
        """
        Roofline-based routing decision.
        break-even: batch_size = bytes_per_weight (FP16 = 2)
        """
        intensity = 2.0 * batch_size / 2.0   # FP16
        if self.gpu_util > self.cfg.gpu_saturation_threshold:
            return DeviceType.CPU
        if intensity < self.cfg.intensity_break_even:
            return DeviceType.CPU
        return DeviceType.GPU

    def update_utilisation(self, gpu: float, cpu: float) -> None:
        self.gpu_util = gpu
        self.cpu_util = cpu

    def pending_count(self) -> int:
        return sum(len(q) for q in self._queues.values())

    def stats_report(self) -> dict:
        s = self.stats
        n_bat = max(s["batches"], 1)
        return {
            "submitted":          s["submitted"],
            "batches_formed":     s["batches"],
            "avg_batch_size":     round(s["requests_batched"] / n_bat, 2),
            "kv_sharing_pairs":   s["kv_sharing_pairs"],
            "pending":            self.pending_count(),
        }
