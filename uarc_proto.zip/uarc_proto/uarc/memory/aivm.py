"""
M2: AI Virtual Memory Manager (AI-VM)
M4: Predictive Layer Loader (PLL)
======================================
Three-tier memory management with CLOCK-Pro eviction,
KV-cache paging, and EMA-based lookahead prefetch scheduling.
"""
from __future__ import annotations

import heapq
import math
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional, Callable

from uarc.core.config import AIVMConfig, PLLConfig
from uarc.core.types import AIPage, KVBlock, MemoryTier, PrefetchOrder


# ══════════════════════════════════════════════════════════════════════════════
# AI Virtual Memory Manager
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TierState:
    tier: MemoryTier
    capacity_mb: float
    used_mb: float = 0.0

    @property
    def free_mb(self) -> float:
        return self.capacity_mb - self.used_mb

    @property
    def pressure(self) -> float:
        return self.used_mb / max(self.capacity_mb, 1.0)


class CLOCKPro:
    """Two-ring CLOCK-Pro eviction (O(1) amortised)."""

    def __init__(self):
        self._hot:  list[str] = []
        self._cold: list[str] = []

    def add(self, pid: str, hot: bool = False) -> None:
        (self._hot if hot else self._cold).append(pid)

    def remove(self, pid: str) -> None:
        for ring in (self._hot, self._cold):
            if pid in ring:
                ring.remove(pid)
                return

    def promote_hot(self, pid: str) -> None:
        if pid in self._cold:
            self._cold.remove(pid)
        if pid not in self._hot:
            self._hot.append(pid)

    def scan_cold(self, pages: dict[str, AIPage], n: int) -> list[str]:
        victims = []
        for pid in list(self._cold):
            if len(victims) >= n:
                break
            page = pages.get(pid)
            if page is None:
                self._cold.remove(pid)
                continue
            if page.pinned or page.transfer_in_progress:
                continue
            if page.referenced:
                page.referenced = False
                self.promote_hot(pid)
            elif page.score() < 0.5:
                victims.append(pid)
        return victims

    def scan_hot(self, pages: dict[str, AIPage],
                 threshold: float = 1.5) -> list[str]:
        demoted = []
        for pid in list(self._hot):
            page = pages.get(pid)
            if page is None or page.score() < threshold:
                demoted.append(pid)
        for pid in demoted:
            if pid in self._hot:
                self._hot.remove(pid)
            self._cold.append(pid)
        return demoted


class KVPageTable:
    """Two-level page table for KV-cache with copy-on-write sharing."""

    def __init__(self):
        self._logical: dict[tuple[str, int], int] = {}
        self._blocks:  dict[int, KVBlock] = {}
        self._next_id  = 0

    def allocate(self, seq_id: str, block_idx: int,
                 page_id: str) -> KVBlock:
        bid = self._next_id
        self._next_id += 1
        blk = KVBlock(block_id=bid, seq_id=seq_id,
                      logical_idx=block_idx, page_id=page_id)
        self._blocks[bid] = blk
        self._logical[(seq_id, block_idx)] = bid
        return blk

    def lookup(self, seq_id: str, block_idx: int) -> Optional[KVBlock]:
        bid = self._logical.get((seq_id, block_idx))
        return self._blocks.get(bid) if bid is not None else None

    def share_prefix(self, src: str, dst: str, n: int) -> int:
        """Zero-copy prefix sharing. Returns number of blocks shared."""
        shared = 0
        for i in range(n):
            bid = self._logical.get((src, i))
            if bid is None:
                break
            self._blocks[bid].ref_count += 1
            self._logical[(dst, i)] = bid
            shared += 1
        return shared

    def free_sequence(self, seq_id: str) -> list[str]:
        """Free all blocks for seq_id. Returns page_ids to release."""
        keys   = [k for k in self._logical if k[0] == seq_id]
        freed  = []
        for k in keys:
            bid  = self._logical.pop(k)
            blk  = self._blocks.get(bid)
            if blk:
                blk.ref_count -= 1
                if blk.ref_count <= 0:
                    freed.append(blk.page_id)
                    del self._blocks[bid]
        return freed

    def cow_on_write(self, seq_id: str,
                     block_idx: int) -> Optional[str]:
        """Copy-on-write trigger. Returns new page_id if copy happened."""
        bid = self._logical.get((seq_id, block_idx))
        if bid is None:
            return None
        blk = self._blocks[bid]
        if blk.ref_count <= 1:
            return None
        blk.ref_count -= 1
        new_pid  = f"kv_{seq_id}_{block_idx}_cow_{int(time.monotonic()*1e6)}"
        new_bid  = self._next_id
        self._next_id += 1
        new_blk  = KVBlock(block_id=new_bid, seq_id=seq_id,
                            logical_idx=block_idx, page_id=new_pid)
        self._blocks[new_bid] = new_blk
        self._logical[(seq_id, block_idx)] = new_bid
        return new_pid


class AIVirtualMemoryManager:
    """
    Three-tier unified memory manager.
    Thread-safe via a single reentrant lock.
    """

    def __init__(self, cfg: AIVMConfig):
        self.cfg = cfg
        self._tiers = {
            MemoryTier.VRAM: TierState(MemoryTier.VRAM, cfg.vram_mb),
            MemoryTier.RAM:  TierState(MemoryTier.RAM,  cfg.ram_mb),
            MemoryTier.NVME: TierState(MemoryTier.NVME, cfg.nvme_mb),
        }
        self._pages:   dict[str, AIPage] = {}
        self._clock    = CLOCKPro()
        self._kv_table = KVPageTable()
        self._lock     = threading.RLock()
        self.stats     = defaultdict(int)

    # ── Page Lifecycle ─────────────────────────────────────────────────────────

    def allocate(self, page_id: str, size_mb: float,
                 data_type: str = "weight",
                 layer_id: Optional[int] = None,
                 seq_id:   Optional[str] = None,
                 preferred_tier: MemoryTier = MemoryTier.NVME,
                 pinned: bool = False) -> AIPage:
        with self._lock:
            for tier in [preferred_tier, MemoryTier.RAM, MemoryTier.NVME]:
                t = self._tiers[tier]
                if t.capacity_mb == 0:
                    continue
                if t.free_mb >= size_mb:
                    page = AIPage(
                        page_id=page_id, size_mb=size_mb,
                        tier=tier, data_type=data_type,
                        layer_id=layer_id, seq_id=seq_id,
                        pinned=pinned,
                    )
                    self._pages[page_id] = page
                    t.used_mb += size_mb
                    self._clock.add(page_id, hot=(tier == MemoryTier.VRAM))
                    self.stats[f"alloc_{tier.label}"] += 1
                    return page
            raise MemoryError(
                f"Cannot allocate {size_mb:.1f}MB — all tiers at capacity")

    def access(self, page_id: str) -> Optional[AIPage]:
        page = self._pages.get(page_id)
        if page is None:
            return None
        page.touch()
        self.stats[f"hit_{page.tier.label}"] += 1
        return page

    def locate(self, page_id: str) -> Optional[MemoryTier]:
        page = self._pages.get(page_id)
        return page.tier if page else None

    def promote(self, page_id: str,
                target: MemoryTier = MemoryTier.VRAM) -> float:
        """Promote page to faster tier. Returns transfer ms."""
        with self._lock:
            page = self._pages.get(page_id)
            if page is None or page.tier <= target:
                return 0.0
            if self._tiers[target].capacity_mb == 0:
                return 0.0   # Tier not available on this hardware
            if self._tiers[target].free_mb < page.size_mb:
                self._evict(target, page.size_mb)
            ms = page.transfer_time_ms(target)
            src = page.tier
            self._tiers[src].used_mb    -= page.size_mb
            self._tiers[target].used_mb += page.size_mb
            page.tier = target
            self._clock.promote_hot(page_id)
            self.stats[f"promote_to_{target.label}"] += 1
            return ms

    def demote(self, page_id: str,
               target: MemoryTier = MemoryTier.RAM) -> float:
        with self._lock:
            page = self._pages.get(page_id)
            if page is None or page.tier >= target or page.pinned:
                return 0.0
            ms = page.transfer_time_ms(target)
            src = page.tier
            self._tiers[src].used_mb    -= page.size_mb
            self._tiers[target].used_mb += page.size_mb
            page.tier = target
            page.referenced = False
            self.stats[f"demote_to_{target.label}"] += 1
            return ms

    def free(self, page_id: str) -> None:
        with self._lock:
            page = self._pages.pop(page_id, None)
            if page:
                self._tiers[page.tier].used_mb -= page.size_mb
                self._clock.remove(page_id)

    # ── Eviction ──────────────────────────────────────────────────────────────

    def _evict(self, tier: MemoryTier, need_mb: float) -> float:
        freed = 0.0
        n = math.ceil(need_mb / self.cfg.page_size_mb) + 2
        victims = self._clock.scan_cold(self._pages, n)
        for pid in victims:
            page = self._pages.get(pid)
            if page is None or page.tier != tier:
                continue
            next_tier_val = page.tier.value + 1
            if next_tier_val <= MemoryTier.NVME:
                next_tier = MemoryTier(next_tier_val)
                self.demote(pid, next_tier)
                freed += page.size_mb
                self.stats["evictions"] += 1
            if freed >= need_mb:
                break
        return freed

    def run_eviction_cycle(self) -> None:
        """Proactive eviction — call periodically."""
        for tier in [MemoryTier.VRAM, MemoryTier.RAM]:
            t = self._tiers[tier]
            if t.pressure > self.cfg.pressure_hi:
                needed = t.capacity_mb * self.cfg.min_free_pct - t.free_mb
                if needed > 0:
                    self._evict(tier, needed)
        self._clock.scan_hot(self._pages)

    # ── KV Cache API ──────────────────────────────────────────────────────────

    def kv_allocate(self, seq_id: str, block_idx: int) -> KVBlock:
        pid = f"kv_{seq_id}_{block_idx}_{int(time.monotonic()*1e6)}"
        self.allocate(pid, size_mb=2.0, data_type="kv_cache",
                      seq_id=seq_id, preferred_tier=MemoryTier.VRAM)
        return self._kv_table.allocate(seq_id, block_idx, pid)

    def kv_lookup(self, seq_id: str,
                  block_idx: int) -> Optional[KVBlock]:
        return self._kv_table.lookup(seq_id, block_idx)

    def kv_share_prefix(self, src: str, dst: str, n: int) -> int:
        return self._kv_table.share_prefix(src, dst, n)

    def kv_free(self, seq_id: str) -> None:
        pids = self._kv_table.free_sequence(seq_id)
        for pid in pids:
            self.free(pid)

    # ── Status ────────────────────────────────────────────────────────────────

    def status(self) -> dict:
        result = {}
        for tier, t in self._tiers.items():
            result[tier.label] = {
                "capacity_mb": round(t.capacity_mb, 1),
                "used_mb":     round(t.used_mb, 1),
                "free_mb":     round(t.free_mb, 1),
                "pressure":    round(t.pressure, 3),
            }
        result["pages"] = len(self._pages)
        result["stats"] = dict(self.stats)
        return result


# ══════════════════════════════════════════════════════════════════════════════
# Predictive Layer Loader
# ══════════════════════════════════════════════════════════════════════════════

class PredictiveLayerLoader:
    """
    M4: EMA-based lookahead prefetch scheduler.
    Integrates with AI-VM to issue async promotions before layers are needed.
    """

    def __init__(self, cfg: PLLConfig, n_layers: int,
                 layer_sizes_mb: list[float],
                 aivm: Optional[AIVirtualMemoryManager] = None):
        self.cfg = cfg
        self.n_layers = n_layers
        self.layer_sizes = layer_sizes_mb
        self.aivm = aivm
        # EMA timing state
        self._exec_ema  = [50.0]  * n_layers   # ms
        self._load_ema  = [200.0] * n_layers   # ms
        self._t_layer_start: float = 0.0
        self._issued: set[int] = set()
        # Async prefetch
        self._queue: list[tuple] = []    # (urgency, layer_id, tier)
        self._lock  = threading.Lock()
        self.on_prefetch: Callable[[PrefetchOrder], None] = lambda o: None
        # Stats
        self.stats = defaultdict(int)

    def on_layer_start(self, layer_id: int) -> None:
        self._t_layer_start = time.perf_counter()

    def on_layer_complete(self, layer_id: int) -> None:
        elapsed = (time.perf_counter() - self._t_layer_start) * 1000
        α = self.cfg.ema_alpha
        self._exec_ema[layer_id] = α * self._exec_ema[layer_id] + (1-α) * elapsed
        self._schedule(layer_id)

    def _schedule(self, done: int) -> None:
        t_now = time.perf_counter() * 1000
        cumulative = 0.0
        for offset in range(1, self.cfg.lookahead_k + 1):
            target = done + offset
            if target >= self.n_layers or target in self._issued:
                continue
            for mid in range(done + 1, target):
                cumulative += self._exec_ema[mid]
            t_need  = t_now + cumulative
            t_load  = self._load_ema[target]
            slack   = t_need - t_load - t_now

            if slack > self.cfg.slack_ms:
                tier = MemoryTier.VRAM if offset <= 2 else MemoryTier.RAM
                order = PrefetchOrder(
                    layer_id=target,
                    target_tier=tier,
                    urgency_ms=slack,
                    estimated_load_ms=t_load,
                )
                with self._lock:
                    heapq.heappush(self._queue, (slack, target, tier.value))
                    self._issued.add(target)
                self.on_prefetch(order)
                self.stats["issued"] += 1
                # Immediately promote if AI-VM is wired
                if self.aivm:
                    pid = f"layer_{target}_weights"
                    if self.aivm.locate(pid) is not None:
                        self.aivm.promote(pid, tier)

    def record_load_time(self, layer_id: int, ms: float) -> None:
        α = self.cfg.ema_alpha
        self._load_ema[layer_id] = α * self._load_ema[layer_id] + (1-α) * ms

    def reset(self) -> None:
        self._issued.clear()
        with self._lock:
            self._queue.clear()

    def stats_report(self) -> dict:
        return {
            "prefetch_issued":    self.stats["issued"],
            "avg_exec_ema_ms":    round(sum(self._exec_ema) / max(self.n_layers, 1), 2),
            "avg_load_ema_ms":    round(sum(self._load_ema) / max(self.n_layers, 1), 2),
        }
